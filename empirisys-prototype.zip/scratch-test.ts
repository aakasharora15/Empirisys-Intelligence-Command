import { runMarketIntelligencePipeline } from './lib/ai/market-intelligence/pipeline';

async function main() {
  console.log("Starting Market Intelligence Pipeline test...");
  try {
    const result = await runMarketIntelligencePipeline();
    console.log("Success! Extracted themes count:", result.themes.length);
    console.log("First theme:", result.themes[0]?.title);
    console.log("Events count:", result.events.length);
    if (result.landscape) {
      console.log("Landscape segments:", result.landscape.segments.length);
    }
  } catch (err) {
    console.error("Pipeline failed:", err);
  }
}
main();
